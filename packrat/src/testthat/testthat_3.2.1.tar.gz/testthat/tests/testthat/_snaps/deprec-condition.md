# is_informative_error is defunct

    Code
      is_informative_error(TRUE)
    Condition
      Error:
      ! `is_informative_error()` was deprecated in testthat 3.0.0 and is now defunct.

