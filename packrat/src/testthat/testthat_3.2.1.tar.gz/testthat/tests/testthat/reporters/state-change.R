test_that("options", {
  options(x = 1)
  expect_true(TRUE)
})
