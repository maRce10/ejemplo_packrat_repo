#' @useDynLib brio, .registration = TRUE
NULL
