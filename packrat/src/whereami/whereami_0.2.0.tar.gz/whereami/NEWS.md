# whereami 0.2.0

* refactor usage of .Internal commands to comply with new CRAN rules

# whereami 0.1.9

* add plot method for counters
* add json output of the counter log
* force winslash to be '/' in normalizePath in winOS
* add counter_tags
* refactor whereami to check breadcrumb at end of the script
* add onLoad and onAttach options to turn on keep.source

# whereami 0.1.8.1

* Added a `NEWS.md` file to track changes to the package.
* Add character class to `whereami()` output object.
* Simplify example in tables vignette
