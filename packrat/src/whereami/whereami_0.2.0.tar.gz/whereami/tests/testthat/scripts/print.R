
foo <- function() {
  
  print(whereami::whereami(tag = 'print test'))
  
}

foo()
