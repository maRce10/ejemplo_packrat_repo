
foo2 <- function() {
  whereami::cat_where(whereami::whereami(tag = 'cat test'))
}

foo2()
