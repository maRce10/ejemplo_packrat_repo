library(testthat)
library(whereami)

test_check("whereami")
